

Put in own folder.

Use this as you wish.

Any suggestions can be directed here:
https://www.arcgames.com/en/forums/startrekonline#/discussion/1238618/star-trek-online-and-pwi-testing-tool